export const DEMO_PHOTO_URL =
  'https://e0.365dm.com/23/11/1600x900/skysports-jude-bellingham-real-madrid_6377097.jpg?20231129223659.'
export const DEMO_PHOTO_URL_2 =
  'https://cms.sabcsport.com/storage/images/1024x768_federico-valverde-of-real-madrid-5-nov-jpg_572x322.webp'
export const DEMO_PHOTO_URL_3 =
  'https://static.independent.co.uk/2023/05/08/17/22-83f076e3fa8d42368c0a517d78e6af6c.jpg?quality=75&width=1000&crop=3%3A2%2Csmart&auto=webp'
export const DEMO_PHOTO_URL_4 =
  'https://pbs.twimg.com/media/GOGV0tdXcAAsnGk?format=jpg&name=900x900'
